
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.swing.text.StyledEditorKit.ForegroundAction;

public class Main {
	public ArrayList<String> corpusArrayList = new ArrayList<String>(10000);

	/**
	 * red file as line
	 * 
	 * 
	 */
	public static ArrayList<String> readTxtFile(String filePath) {
		Main main = new Main();
		try {
			String encoding = "UTF-8";
			File file = new File(filePath);
			if (file.isFile() && file.exists()) { // file exsit?
				InputStreamReader read = new InputStreamReader(
						new FileInputStream(file), encoding);// thansor coding
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;
				String[] temp;
				while ((lineTxt = bufferedReader.readLine()) != null) {
					temp = lineTxt.split(" ");
					for (int i = 0; i < temp.length; i++) {
						main.corpusArrayList.add(temp[i].toLowerCase());//change to lowercase
					}
				}
				read.close();
			} else {
				System.out.println("no file");
			}
		} catch (Exception e) {
			System.out.println("error in reading");
			e.printStackTrace();
		}
		return main.corpusArrayList;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		ArrayList<String> corpus;
		String filePath = "corpus.txt";
		// "res/";
		double time1 = 0;
		double time2 = 0;
		corpus = readTxtFile(filePath);
		
		time2 = System.currentTimeMillis();
		System.out.println(corpus.size()+" corpus size ");

		corpus = Puntation.check(corpus);
		time1 = System.currentTimeMillis();
		System.out.println(corpus.size()+" corpus size without punctuation");

	
		WordFre wordFre = new WordFre();   
		for (int i = 0; i < corpus.size() - 1; i++){
			Word word =new Word(corpus.get(i));
			wordFre.Add(word);  
		} 
		time1 = System.currentTimeMillis();
		Frequency frequency = new Frequency();
		for (int i = 0; i < corpus.size() - 1; i++) {
			Phrase phase = new Phrase(corpus.get(i), corpus.get(i + 1));
			frequency.Add(phase);
		}
		time2 = System.currentTimeMillis();
		System.out.println(" phrase size " + frequency.getPhaseList().size());

		frequency.setPhaseList(StopList.check(frequency.getPhaseList()));
		//time1 = System.currentTimeMillis();
		System.out.println("phrase size without stoplist " + frequency.getPhaseList().size());
		System.out.println("The top 20 frequency tokens are");
		int count =0;
		for (int i = 1000; i > 0; i--) {
			for (int j = 0; j < frequency.getPhaseList().size(); j++) {
				if (frequency.getPhaseList().get(j).getFrequency() == i) {
					System.out.println(frequency.getPhaseList().get(j).getPhrase() + " frequency "+ i );
				count++;
				break;
				}
			}
			if (count==20)break; {
				
			}
		}
		
		
	  

	 /***
	  int pos = 20;
	  int t=0;
	  int p=0;
	  while (pos!=0) {
		for (int i=1000; i>0; i--){
		  for (int j = 0; j < frequency.getPhaseList().size(); j++) {
			if (i == frequency.getPhaseList().get(j).getFrequency()) {
				t=i; p=j;
				pos --;
				break;
				
			}
		  }
		}				
		System.out.println(t + ": " + pos + ": "
				 + frequency.getPhaseList().get(p).getPhrase());}
/*
 * 
 */



   
       int N=frequency.getPhaseList().size()-1;
       //System.out.println("done  " + frequency.getPhaseList().size());
       //System.out.println(N);
       double []c12= new double [N];
       double []c1= new double [N];
       double []c2=new double [N];
       double []m=new double [N];
       System.out.println("The top 20 PMI tokens are");
       for(int i=0;i < frequency.getPhaseList().size()-1;i++){
        c12[i]=frequency.getPhaseList().get(i).getFrequency();
        c1[i]=wordFre.getwordList().get(i).getWordFre();
        c2[i]=wordFre.getwordList().get(i+1).getWordFre();
    	   m[i] =c12[i]*N/(c1[i]*c2[i]);
       
            frequency.getPhaseList().get(i).setPmi(PMI.log(m[i],2));  
          }
       int count2 =0;
		for (int i = 20000; i > 0; i--) {
			for (int j = 0; j < frequency.getPhaseList().size(); j++) {
				if ((int)frequency.getPhaseList().get(j).getPmi() == i) {
					System.out.println(frequency.getPhaseList().get(j).getPhrase() +" pmi "+ i );
				count++;
				break;
				}
			}
			if (count2==20)break; {
				
			}
		}
      
//       double maxp = 0;
//		int posp = 0;
//		for (int i = 0; i < frequency.getPhaseList().size()-1; i++) {
//			if (maxp < frequency.getPhaseList().get(i).getPmi() ) {
//				maxp = frequency.getPhaseList().get(i).getPmi();
//				posp = i;
//			}
//		}
//		System.out.println(maxp + ": " + posp + ": "
//				+ frequency.getPhaseList().get(posp).getPhrase());
		double []o11 =new double[N]; 
		double []o12 =new double[N]; 
		double []o21 =new double[N]; 
		double []o22 =new double[N]; 
		double []x =new double[N]; 
		double []y =new double[N]; 
		double []xchi= new double[N];
		double []dlog= new double[N];
		System.out.println("The top 20 Xchi tokens are");
		for(int i=0;i < frequency.getPhaseList().size()-1;i++){
			 c12[i]=frequency.getPhaseList().get(i).getFrequency();
         c1[i]=wordFre.getwordList().get(i).getWordFre();
         c2[i]=wordFre.getwordList().get(i+1).getWordFre();
			o11[i]=c12[i];
			o12[i]=c1[i]-c12[i];
			o21[i]=c2[i]-c12[i];
			o22[i]=N-o11[i]-o12[i]-o21[i];
			x[i]=N*(o11[i]*o12[i]-o12[i]*o21[i])*(o11[i]*o12[i]-o12[i]*o21[i]);
			y[i]=(o11[i]+o12[i])*(o11[i]+o21[i])*(o12[i]+o22[i])*(o21[i]+o22[i]);
			xchi[i]=x[i]/y[i];
			dlog[i]=xchi[i]/(-2);
			frequency.getPhaseList().get(i).setXchi(xchi[i]);
			frequency.getPhaseList().get(i).setdrt(dlog[i]);
		}
		 int count3 =0;
			for (int i = 20000; i > 0; i--) {
				for (int j = 0; j < frequency.getPhaseList().size(); j++) {
					if ((int)frequency.getPhaseList().get(j).getXchi() == i) {
						System.out.println(frequency.getPhaseList().get(j).getPhrase() +" Xchi "+ i );
					count3++;
					break;
					}
				}
				if (count3==20)break; {
					
				}
			}
			System.out.println("The top 20 Dunning's log-likelihood test tokens are");
			 int count4 =0;
				for (int i = -20000; i < 0; i++) {
					for (int j = 0; j < frequency.getPhaseList().size(); j++) {
						if ((int)frequency.getPhaseList().get(j).getdrt() == i) {
							System.out.println(frequency.getPhaseList().get(j).getPhrase() +" Logdrt "+ i );
						count4++;
						break;
						}
					}
					if (count4==20)break; {
						
					}
				}
//		double maxx = 0;
//		int posx = 0;
//		for (int i = 0; i < frequency.getPhaseList().size()-1; i++) {
//			if (maxx < xchi[i] ) {
//				maxx = xchi[i];
//				posx = i;
//			}
//		}
//		System.out.println(maxx + ": " + posx + ": "+ frequency.getPhaseList().get(posx).getPhrase());
		  }
}
