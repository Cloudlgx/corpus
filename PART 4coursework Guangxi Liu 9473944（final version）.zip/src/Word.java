public class Word {
	private String word = "";
	private int wordFre = 0;

	public String getWord(){
		return new String(this.word);
	}
	
	public void setWord(String word) {
		this.word = word;
	}


	public int getWordFre() {
		return wordFre;
	}
	public void addWordFre(){
		this.wordFre++;
	}
	public void setWordFer(int wordFre) {
		this.wordFre = wordFre;
	}
	public Word(String a) {
		this.word = a;
		this.wordFre = 1;
	}
}
