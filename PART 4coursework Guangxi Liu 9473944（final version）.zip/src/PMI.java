public class PMI {  
static public double log(double value, double base) 
    {  
	double a = Math.log(value) / Math.log(base);  
          return a;
    }
}
