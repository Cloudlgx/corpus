import java.util.ArrayList;

public class WordFre {

	 private ArrayList<Word> wordList= new ArrayList<Word>(100000);
	 public WordFre() {
	 wordList.add(new Word(""));
	 }
	
	 public void Add(Word word ) {
	 for (int i = 0; i < wordList.size(); i++) {
	 if (wordList.get(i).getWord().equals(word.getWord())) {
	 wordList.get(i).addWordFre();
	 break;
	 }
	 }
	 wordList.add(word);
	 }
	
	 public ArrayList<Word> getwordList() {
	 return wordList;
	 }
	
	 public void setWordList(ArrayList<Word> wordList) {
	 this.wordList = wordList;
	 }
}