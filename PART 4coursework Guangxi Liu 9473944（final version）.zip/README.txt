Note:
Extract the zip in the folder,Using Eclipes imprort the project or import all the files in folder src/ to a new project in Eclipes. 

Note: 
1.The project can lord the corpus file.
2.It can change or the words to lowercase.
3.The project can filter the stoplist and punctuation of the corpus and calculate the value of the coursework.

Note:
You should copy the corpus file in the folder, if you want to choose a new one, Please load the file in the project, and using the same name "corpus.txt" with project file path.
you can edit the file path in the folder src/main.java, 
String filePath = "corpus.txt";or change the Sring filepath by youself, it is vert important to make the program run successfully.


Result analysis

The programe can filter the stoplist and punctuation easily, I think the most value of the result is reseanable, but it may have some issues,
because I transfer final results to integer values.

